document.getElementById("popup").innerHTML=`
<a name="top"></a>
<h1>My Prompts dev <span id="myVersion" class="label" style="font-size:15px; color:#8ebf42;"></span></h1>





<div class="tab">
  <button class="tablinks" id="Config1">Config1</button>
  <button class="tablinks" id="Config2">Config2</button>
  <button class="tablinks" id="Config3">Config3</button>
  <button class="tablinks" id="Config4">Config4</button>
  <button class="tablinks" id="fullPage" style="font-size:10px; color:red;">Full Page</button>
  
</div>
<fieldset>
  <button id="backup">Export</button>
  <button id="restore">Import</button>
  <button id="save">Save</button>
  <input type="file" style="display:none;" id="file-selector">
  <button id="deleteAll">Clear All</button>

  <input type="file" style="display:none;" id="file-selector">    <button id="github">Import from Github</button>

 
  <a href="https://github.com/Octopus120/myPromptsConfig/tree/main" id='howToSetup' target="_blank" class="btn btn-warning teaser">How to use?</a>
  <a href="https://chromewebstore.google.com/detail/my-prompts/ohmlhcmmjbponikechknmhedgojoaamp" target="_blank" class="btn btn-warning teaser">Please Rate Us</a>
 
</fieldset>
<div id="status1" style="color: #06038D"></div>
<ul id="listContainer"></ul>
<fieldset>
  <a href="#variable" style="margin-right: 20px;">Variables</a>
  <a href="#shortcut" style="margin-right: 20px;">Auto expand</a>
  <a href="#complete" style="margin-right: 20px;">Auto complete</a>
  <a href="#hide" style="margin-right: 20px;">Auto hide</a>
  <a href="#click" style="margin-right: 20px;">Auto click</a>
  <a href="#fill" style="margin-right: 20px;">Auto fill</a>
  <a href="#control" style="margin-right: 20px;">Hot key</a>
  <a href="#bookmark" style="margin-right: 0;">Bookmarks with comments</a>
</fieldset>


<a name="variable"></a>
<label for="explicit-label-name" style="font-size:20px;">Variables:</label>
<fieldset>
  <button id="addRow06">Add</button>
  <button id="save06">Save</button>
  <button id="helpShortcut">?</button>
  <a href="#top">Back to top</a>
  <div id="status06" style="color: #06038D"></div>
</fieldset>
<table id="table06" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>


<a name="shortcut"></a>
<label for="explicit-label-name" style="font-size:20px;">Auto expand text using shortcuts:</label>
<fieldset>
  <button id="addRow02">Add</button>
  <button id="save02">Save</button>
  <button id="helpShortcut">?</button>
  <a href="#top">Back to top</a>
  <div id="status02" style="color: #06038D"></div>
</fieldset>
<table id="table02" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>


<a name="complete"></a>
<label for="explicit-label-name" style="font-size:20px;">Auto complete sentences:</label>
<fieldset>
  <button id="addRow03">Add</button>
  <button id="save03">Save</button>
  <button id="helpSentence">?</button>
  <a href="#top">Back to top</a>
  <div id="status03" style="color: #06038D"></div>
</fieldset>
<table id="table03" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>


<a name="hide"></a>
<label for="explicit-label-name" style="font-size:20px;">Auto hide web elements:</label>
<fieldset>
  <button id="addRow04">Add</button>
  <button id="save04">Save</button>
  <a href="#top">Back to top</a>
</fieldset>
<div id="status04" style="color: #06038D"></div>
<table id="table04" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>

<a name="click"></a>
<label for="explicit-label-name" style="font-size:20px;">Auto click buttons or links:</label>
<fieldset>
  <button id="addRow00">Add</button>
  <button id="save00">Save</button>
  <a href="#top">Back to top</a>
</fieldset>
<div id="status00" style="color: #06038D"></div>
<table id="table00" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>


<a name="fill"></a>
<label for="explicit-label-name" style="font-size:20px;">Auto fill forms:</label>
<fieldset>
  <button id="addRow05">Add</button>
  <button id="save05">Save</button>
  <a href="#top">Back to top</a>
</fieldset>
<div id="status05" style="color: #06038D"></div>
<table id="table05" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>


<a name="control"></a>
<label for="explicit-label-name" style="font-size:20px;">Keyboard hot key to navigate web pages and click buttons:</label>
<fieldset>
  <button id="addRow01">Add</button>
  <button id="save01">Save</button>
  <a href="#top">Back to top</a>
</fieldset>
<div id="status01" style="color: #06038D"></div>
<table id="table01" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>

<a name="bookmark"></a>
<label for="explicit-label-name" style="font-size:20px;">Bookmark with Comments:</label>
<fieldset>
  <button id="addRow07">Add</button>
  <button id="save07">Save</button>
  <a href="#top">Back to top</a>
</fieldset>
<div id="status01" style="color: #06038D"></div>
<table id="table07" border="1" cellpadding="1" cellspacing="1" width="100%">
  <tbody id="tableBody" class="row_drag"></tbody>
</table>

`;var f={},b={},h={},p={},y={},v={},E={},k={},w=new Map;function t(e,t){w.set("current",t),d();var n=document.getElementsByClassName("tablinks");for(let e=0;e<n.length;e++)n[e].style.backgroundColor="";document.getElementById(w.get("current")).style.backgroundColor="yellow","Config1"===w.get("current")?chrome.storage.local.get({configa:"configa"},function(e){"configa"!==e.configa&&l(JSON.parse(e.configa))}):"Config2"===w.get("current")?chrome.storage.local.get({configb:"configb"},function(e){"configb"!==e.configb&&l(JSON.parse(e.configb))}):"Config3"===w.get("current")?chrome.storage.local.get({configc:"configc"},function(e){"configc"!==e.configc&&l(JSON.parse(e.configc))}):"Config4"===w.get("current")&&chrome.storage.local.get({configd:"configd"},function(e){"configd"!==e.configd&&l(JSON.parse(e.configd))})}function l(e){f={},b={},h={},p={},y={},v={},E={},k={};let n=e[1];if(null==n)B("","");else{var l=Object.keys(n);for(let e=0;e<l.length;e++)f[e]=[n[l[e]][0],n[l[e]][1]],B(n[l[e]][0],n[l[e]][1])}var t,o={};let a=0;for(t of w.keys())o[a]=[t,w.get(t)],a++;var r=JSON.stringify(o);if(chrome.storage.local.set({myConfigs:r},function(){}),null==(n=e[2]))x("","");else{l=Object.keys(n);for(let e=0;e<l.length;e++)b[e]=[n[l[e]][0],n[l[e]][1]],x(n[l[e]][0],n[l[e]][1])}if(null==(n=e[3]))I("","");else{l=Object.keys(n);for(let e=0;e<l.length;e++)h[e]=[n[l[e]][0],n[l[e]][1]],I(n[l[e]][0],n[l[e]][1])}if(null==(n=e[4]))C("","");else{var d=new Map,l=Object.keys(n);for(let t=0;t<l.length;t++){let e=n[l[t]][1];var s=e.split(/\r\n|\r|\n/),i=s[s.length-2];1<s.length&&-1==i.indexOf("}")&&!e.endsWith("myFirstName")&&(e+="\nmyFirstName"),p[t]=[n[l[t]][0],e],d.set(e,n[l[t]][0])}var c,u=new Map([...d.entries()].sort((e,t)=>t[1].localeCompare(e[1])));for(c of u.keys())C(u.get(c),c)}if(null==(n=e[5]))N("","");else{d=new Map,l=Object.keys(n);for(let e=0;e<l.length;e++)y[e]=[n[l[e]][0],n[l[e]][1]],d.set(n[l[e]][1],n[l[e]][0]);var m,g=new Map([...d.entries()].sort((e,t)=>e[0]<t[0]?1:e[0]>t[0]?-1:0));for(m of g.keys())N(g.get(m),m)}if(null==(n=e[6]))L("","");else{l=Object.keys(n);for(let e=0;e<l.length;e++)v[e]=[n[l[e]][0],n[l[e]][1]],L(n[l[e]][0],n[l[e]][1])}if(null==(n=e[7]))O("","");else{l=Object.keys(n);for(let e=0;e<l.length;e++)E[e]=[n[l[e]][0],n[l[e]][1]],O(n[l[e]][0],n[l[e]][1])}if(null==(n=e[8]))A("","");else{l=Object.keys(n);for(let e=0;e<l.length;e++)k[e]=[n[l[e]][0],n[l[e]][1]],A(n[l[e]][0],n[l[e]][1])}}function B(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
    <td class="table-btn"><button class="button-delete" id="deleteRow06">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Variable" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
  `;e=document.getElementById("table06").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow06").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()})}function x(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
    <td class="table-btn"><button class="button-delete" id="deleteRow00">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
  `;e=document.getElementById("table00").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow00").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()})}function I(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
    <td class="table-btn"><button class="button-delete" id="deleteRow01">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f1" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
  `;e=document.getElementById("table01").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow01").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()}),document.getElementById("f1").addEventListener("blur",function(e){var t=new Map,n=document.getElementById("table01").rows.length;for(let e=0;e<n;e++){var l=document.getElementById("table01").rows[e].cells[0].children[0].value.trim();0!=l.length&&(t.has(l)?(this.focus(),i("Dulplicate value: "+l,5e3)):t.set(l,""))}})}function C(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
      <td class="table-btn" > <button class="button-delete" id="deleteRow02">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
      `;e=document.getElementById("table02").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow02").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()}),document.getElementById("f2").addEventListener("blur",function(e){var t=new Map,n=document.getElementById("table02").rows.length;for(let e=0;e<n;e++){var l=document.getElementById("table02").rows[e].cells[0].children[0].value.trim().split(/\s+/)[0];0!=l.length&&(t.has(l)?(i("Dulplicate value: "+l,5e3),this.focus()):t.set(l,""))}})}function N(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
        <td class="table-btn" > <button class="button-delete" id="deleteRow03">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
      `;e=document.getElementById("table03").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow03").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()})}function L(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
        <td class="table-btn" > <button class="button-delete" id="deleteRow04">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
      `;e=document.getElementById("table04").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow04").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()})}function O(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
        <td class="table-btn" > <button class="button-delete" id="deleteRow05">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
      `;e=document.getElementById("table05").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow05").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()})}function A(e,t){var n=document.createElement("tr"),l=0,o=t.split("\n");for(let e=0;e<o.length;e++)l+=Math.ceil(o[e].length/80);n.className="input",n.innerHTML=`
        <td class="table-btn" > <button class="button-delete" id="deleteRow07">Delete</button></td>
    <td><a href="#top">Top</a></td>
    <td class="textarea-shortcut"><textarea id="f2" type="text" rows="${l}" placeholder="Shortcut" class="shortcut form-control">${e}</textarea></td>
    <td class="textarea"><textarea rows="${l}" placeholder="Something" class="autotext" onkeyup="textAreaAdjust(this)">${t}</textarea></td>
      `;e=document.getElementById("table07").tBodies[0];e.insertBefore(n,e.firstChild),document.getElementById("deleteRow07").addEventListener("click",function(e){for(var t=this;t.parentNode&&"tr"!=t.tagName.toLowerCase();)t=t.parentNode;t.parentNode.removeChild(t),e.preventDefault()})}document.addEventListener("visibilitychange",function(){"visible"===document.visibilityState&&location.reload()}),document.addEventListener("DOMContentLoaded",function(e){var t;window.chrome?(t=chrome.runtime.getManifest().version,document.getElementById("myVersion").innerText=t):(t=chrome.runtime.getManifest().version,document.getElementById("myVersion").innerText=t),chrome.storage.local.get({myConfigs:"myConfigs"},function(e){if("myConfigs"!=e.myConfigs){var t=JSON.parse(e.myConfigs),n=Object.keys(t);for(let e=0;e<n.length;e++)null!=t[n[e]][0]&&w.set(t[n[e]][0],t[n[e]][1]),null!=t[n[e]][0]&&t[n[e]][0].startsWith("Config")&&3<t[n[e]][1].length&&(document.getElementById(t[n[e]][0]).innerText=t[n[e]][1])}(w.has("current")&&w.get("current")?document.getElementById(w.get("current")):$("#Config1")).click()})}),document.getElementById("fullPage").addEventListener("click",function(e){chrome.runtime.openOptionsPage(()=>{chrome.runtime.lastError})}),800<window.innerWidth?document.getElementById("fullPage").style.display="none":document.getElementById("fullPage").click(),document.getElementById("Config1").addEventListener("click",function(e){t(0,"Config1")}),document.getElementById("Config2").addEventListener("click",function(e){t(0,"Config2")}),document.getElementById("Config3").addEventListener("click",function(e){t(0,"Config3")}),document.getElementById("Config4").addEventListener("click",function(e){t(0,"Config4")}),document.getElementById("save").addEventListener("click",function(e){i("Config saved",5e3),s()}),document.getElementById("save06").addEventListener("click",function(e){s(),i("Config saved",5e3)}),document.getElementById("save00").addEventListener("click",function(e){s(),i("Config saved",5e3)}),document.getElementById("addRow06").addEventListener("click",function(e){B("","")}),document.getElementById("addRow00").addEventListener("click",function(e){x("","")}),document.getElementById("save01").addEventListener("click",function(e){s()}),document.getElementById("addRow01").addEventListener("click",function(e){I("","")}),document.getElementById("save02").addEventListener("click",function(e){i("Config saved",5e3),s()}),document.getElementById("addRow02").addEventListener("click",function(e){C("","")}),document.getElementById("save03").addEventListener("click",function(e){i("Config saved",5e3),s()}),document.getElementById("addRow03").addEventListener("click",function(e){N("","")}),document.getElementById("save04").addEventListener("click",function(e){s()}),document.getElementById("addRow04").addEventListener("click",function(e){L("","")}),document.getElementById("save05").addEventListener("click",function(e){s()}),document.getElementById("save07").addEventListener("click",function(e){s()}),document.getElementById("addRow05").addEventListener("click",function(e){O("","")}),document.getElementById("addRow07").addEventListener("click",function(e){A("","")}),document.getElementById("backup").addEventListener("click",function(e){var t,n,l,o={urls:f,keywords:b,controls:h,shortcuts:p,sentences:y,hides:v,fills:E,bookmark:k},a=(t=new Date,a=t.getFullYear(),r=("0"+(t.getMonth()+1)).slice(-2),d=("0"+t.getDate()).slice(-2),n=("0"+t.getHours()).slice(-2),l=("0"+t.getMinutes()).slice(-2),t=("0"+t.getSeconds()).slice(-2),a+` -${r} -${d} -${n} -${l} -${t} `),r=JSON.stringify(o).replace(/#/g,"&NPOUND").replace(/:{/g,":\n {").replace(/],/g,"],\n  ").replace(/},/g,"},\n\n"),d=new Blob([r],{type:"text/plain"});chrome.downloads.download({url:URL.createObjectURL(d),filename:"Config."+w.get(w.get("current")).replace(/\s+/g,"-")+"."+a+".json".replace(/\s+/g,""),conflictAction:"uniquify",saveAs:!0},function(e){})}),document.getElementById("restore").addEventListener("click",function(e){document.getElementById("file-selector").click()});document.getElementById("file-selector").addEventListener("change",e=>{var a,e=e.target.files,t=new FileReader;t.onload=function(e){e=e.target.result;if(0!==(a=e.replace(/&NPOUND/g,"#")).length){d();var t=JSON.parse(a);if(null!=t){var n=Object.keys(t);for(let e=0;e<n.length;e++)switch(n[e]){case"urls":var l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)B(l[o[e]][0],l[o[e]][1]);break;case"keywords":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)x(l[o[e]][0],l[o[e]][1]);break;case"controls":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)I(l[o[e]][0],l[o[e]][1]);break;case"shortcuts":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)C(l[o[e]][0],l[o[e]][1]);break;case"sentences":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)N(l[o[e]][0],l[o[e]][1]);break;case"hides":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)L(l[o[e]][0],l[o[e]][1]);break;case"fills":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)O(l[o[e]][0],l[o[e]][1]);break;case"bookmark":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)A(l[o[e]][0],l[o[e]][1])}s()}}},t.readAsText(e[0])});var r={header:{Accept:"application/vnd.github.v3+json",Authorization:""},baseUrl:"https://api.github.com",username:"octopus120",nameRepo:"myPromptsConfig",sha:"",path:"",newFile:!1};function n(){a("GET",r.baseUrl+"/repos/"+r.username+"/"+r.nameRepo+"/branches/main",null,function(e){a("GET",JSON.parse(e).commit.commit.tree.url+"?recursive=1",null,function(e){var t,n,l=JSON.parse(e),o=document.getElementById("listContainer");for(t in o.innerHTML="",l.tree)l.tree[t].path.endsWith(".json")&&((n=document.createElement("li")).url=l.tree[t].url,n.path=l.tree[t].path,n.innerHTML=n.path,n.onclick=function(){var e=this.url,t=this.path;r.path=t,r.newFile=!1,a("GET",e,null,function(e){c();e=JSON.parse(e.replace(/&NPOUND/g,"#"));if(c(),"base64"!=e.encoding)c(e.encoding);else{var t=JSON.parse(decodeURIComponent(escape(window.atob(e.content))));if(c(atob(e.content)),null!=t){d();var n=Object.keys(t);for(let e=0;e<n.length;e++)switch(n[e]){case"urls":var l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)B(l[o[e]][0],l[o[e]][1].replace(/&NPOUND/g,"#"));break;case"keywords":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)x(l[o[e]][0],l[o[e]][1].replace(/&NPOUND/g,"#"));break;case"controls":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)I(l[o[e]][0].replace(/&NPOUND/g,"#"),l[o[e]][1]);break;case"shortcuts":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)C(l[o[e]][0].replace(/&NPOUND/g,"#"),l[o[e]][1]);break;case"sentences":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)N(l[o[e]][0],l[o[e]][1]);break;case"hides":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)L(l[o[e]][0],l[o[e]][1].replace(/&NPOUND/g,"#"));break;case"fills":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)O(l[o[e]][0],l[o[e]][1].replace(/&NPOUND/g,"#"));break;case"bookmark":l=t[n[e]],o=Object.keys(l);for(let e=0;e<o.length;e++)A(l[o[e]][0].replace(/&NPOUND/g,"#"),l[o[e]][1].replace(/&NPOUND/g,"#"))}s()}}}),document.getElementById("listContainer").innerHTML="",document.getElementById("status1"),status1.textContent="Configuration is impoted!",setTimeout(()=>{status1.textContent=""},3e3)},o.appendChild(n));document.getElementById("status1").textContent="Please click any of the following profile to import:"})})}function d(){$("#table00").find("tr").remove(),$("#table01").find("tr").remove(),$("#table02").find("tr").remove(),$("#table03").find("tr").remove(),$("#table04").find("tr").remove(),$("#table05").find("tr").remove(),$("#table06").find("tr").remove(),$("#table07").find("tr").remove()}function s(){null==w.get("current")&&w.set("current","Config1");let t=!(f={});var e,l=document.getElementById("table06").rows.length;for(let e=0;e<l;e++){var n=document.getElementById("table06").rows[l-e-1].cells[2].children[0].value,o=document.getElementById("table06").rows[l-e-1].cells[3].children[0].value;f[e]=[n,o],"URLs"===n?(t=!0,w.set(w.get("current"),o),document.getElementById(w.get("current")).innerText=o):"chatSessionURL"!==n&&"ticketURL"!==n||chrome.storage.local.set({[n]:o},function(){})}for(let n=0;n<l;n++){let e=w.get(w.get("current"))+document.getElementById("table06").rows[l-n-1].cells[2].children[0].value,t=document.getElementById("table06").rows[l-n-1].cells[3].children[0].value;chrome.storage.local.set({[e]:t},function(){})}t||(document.getElementById(w.get("current")).innerText=w.get("current"),w.set(w.get("current"),""));let a={},r=0;for(e of w.keys())a[r]=[e,w.get(e)],r++;var n="myConfigs",d=JSON.stringify(a),l=(chrome.storage.local.set({[n]:d},function(){}),b={},document.getElementById("table00").rows.length);for(let e=0;e<l;e++){n=document.getElementById("table00").rows[l-e-1].cells[2].children[0].value,o=document.getElementById("table00").rows[l-e-1].cells[3].children[0].value;n&&(b[e]=[n,o])}h={},l=document.getElementById("table01").rows.length;for(let e=0;e<l;e++){n=document.getElementById("table01").rows[l-e-1].cells[2].children[0].value.trim(),o=document.getElementById("table01").rows[l-e-1].cells[3].children[0].value.trim();n&&(h[e]=[n,o])}p={};var s=new Map,i=(r=0,document.getElementById("table02").rows.length);for(let e=0;e<i;e++){n=document.getElementById("table02").rows[i-e-1].cells[2].children[0].value.trim(),o=document.getElementById("table02").rows[i-e-1].cells[3].children[0].value.trim();if(n){let e=n.split(/\s+/)[0];s.has(e)&&s.get(e)!=n+o&&(s.has(e+"a")?(n=n.replace(e,e+"b"),e+="b"):(n=n.replace(e,e+"a"),e+="a")),s.set(e,n+o),p[r++]=[n,o]}}var c=new Map,u=(y={},r=0,document.getElementById("table03").rows.length);for(let e=0;e<u;e++){n=document.getElementById("table03").rows[u-e-1].cells[2].children[0].value.trim(),o=document.getElementById("table03").rows[u-e-1].cells[3].children[0].value.trim();!n||c.has(o)||(y[r++]=[n,o],c.set(o,""))}v={},l=document.getElementById("table04").rows.length;for(let e=0;e<l;e++){n=document.getElementById("table04").rows[l-e-1].cells[2].children[0].value.trim(),o=document.getElementById("table04").rows[l-e-1].cells[3].children[0].value.trim();v[e]=[n,o]}E={},l=document.getElementById("table05").rows.length;for(let e=0;e<l;e++){n=document.getElementById("table05").rows[l-e-1].cells[2].children[0].value.trim(),o=document.getElementById("table05").rows[l-e-1].cells[3].children[0].value.trim();E[e]=[n,o]}k={},l=document.getElementById("table07").rows.length;for(let e=0;e<l;e++){n=document.getElementById("table07").rows[l-e-1].cells[2].children[0].value.trim(),o=document.getElementById("table07").rows[l-e-1].cells[3].children[0].value.trim();k[e]=[n,o]}function m(){{var n=document.getElementById("status01");let e=document.getElementById("status02"),t=document.getElementById("status03");var l=document.getElementById("status04"),o=document.getElementById("status05");setTimeout(function(){n.textContent="",e.textContent="",t.textContent="",l.textContent="",o.textContent=""},3e3)}}d={},d[1]=f,d[2]=b,d[3]=h,d[4]=p,d[5]=y,d[6]=v,d[7]=E,d[8]=k,d=JSON.stringify(d);"Config1"===w.get("current")?chrome.storage.local.set({configa:d},m):"Config2"===w.get("current")?chrome.storage.local.set({configb:d},m):"Config3"===w.get("current")?chrome.storage.local.set({configc:d},m):"Config4"===w.get("current")&&chrome.storage.local.set({configd:d},m),document.body.scrollTop=0,document.documentElement.scrollTop=0}function a(e,t,n,l){var o,a=new XMLHttpRequest;for(o in a.onreadystatechange=function(){4!=a.readyState||200!=a.status&&201!=a.status||l(a.responseText)},a.open(e,t,!0),r.header)a.setRequestHeader(o,r.header[o]);a.send(n)}function i(e,t){var n=document.getElementById("tempAlertDiv"),l=(n&&n.parentNode.removeChild(n),document.createElement("div"));l.setAttribute("id","tempAlertDiv"),l.setAttribute("style","position:absolute;top:2%;left:2%;background-color:black;padding:10px;color:white;border-radius:5px;"),l.innerHTML=e,setTimeout(function(){l.parentNode&&l.parentNode.removeChild(l)},t),document.body.appendChild(l)}function c(){}document.getElementById("github").addEventListener("click",function(e){n()}),document.getElementById("deleteAll").addEventListener("click",function(e){d()});